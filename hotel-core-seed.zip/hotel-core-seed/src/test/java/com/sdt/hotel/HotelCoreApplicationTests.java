package com.sdt.hotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
